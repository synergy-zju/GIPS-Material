/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.zju.file;

/**
 *
 ** @author Zhongxu Zhu
 */
public class POS extends CommonInputFile{

        public POS(String path) {
                super(path);
        }
        protected void check(){
                super.check();
        }
}
