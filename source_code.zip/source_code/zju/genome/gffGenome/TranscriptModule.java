package edu.zju.genome.gffGenome;

/**
 *
 * @author zzx
 */
public class TranscriptModule extends Module{
        public TranscriptModule(String ModuleID, String feature, String parent, int startPosition, int endPositon) {
                super(ModuleID, feature, parent, startPosition, endPositon);
        }
        
}
